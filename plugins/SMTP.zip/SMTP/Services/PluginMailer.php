<?php

namespace Plugins\SMTP\Services;

use App\Models\Plugin;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

class PluginMailer
{
    public function send(string $to, string $subject, string $html, array $attachments = [], ?string $from = null, ?string $fromName = null): void
    {
        $row = Plugin::where('slug', 'smtp')->first();
        if (!$row || !$row->is_active) {
            throw new \RuntimeException('SMTP plugin inactivo.');
        }

        $cfg = (array) ($row->config ?? []);

        // Host puede venir como ssl://host:465 o tls://host:587
        $rawHost    = (string) ($cfg['host'] ?? '');
        $host       = $rawHost;
        $port       = isset($cfg['port']) ? (int) $cfg['port'] : null;
        $encryption = $cfg['encryption'] ?? null; // 'ssl'|'tls'|null

        if (preg_match('~^(?:(ssl|tls)://)?([^:/]+)(?::(\d+))?$~i', $rawHost, $m)) {
            $scheme = strtolower($m[1] ?? '');
            $host   = $m[2];
            $hPort  = isset($m[3]) ? (int)$m[3] : null;

            if (!$encryption && $scheme) $encryption = $scheme;
            if (!$port && $hPort)        $port = $hPort;
        }
        if (!$port) {
            $port = ($encryption === 'ssl') ? 465 : 587;
        }

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = $host;
            $mail->SMTPAuth   = true;
            $mail->Username   = $cfg['username'] ?? '';
            $mail->Password   = $cfg['password'] ?? '';
            $mail->Port       = $port;

            if ($encryption === 'ssl')      { $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; }
            elseif ($encryption === 'tls')  { $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; }
            else                             { $mail->SMTPSecure = false; }

            // Opciones de certificado (para self-signed o mismatch)
            $allowSelf  = (bool)($cfg['allow_self_signed'] ?? false);
            $skipVerify = (bool)($cfg['skip_host_verify'] ?? false);
            if ($allowSelf || $skipVerify) {
                $mail->SMTPOptions = [
                    'ssl' => [
                        'verify_peer'       => !$skipVerify,
                        'verify_peer_name'  => !$skipVerify,
                        'allow_self_signed' => $allowSelf,
                    ],
                ];
            }

            // From
            $fromAddr = $from     ?? ($cfg['from_email'] ?? 'no-reply@'.parse_url(config('app.url'), PHP_URL_HOST) ?? 'localhost');
            $fromName = $fromName ?? ($cfg['from_name']  ?? config('app.name', 'App'));
            $mail->setFrom($fromAddr, $fromName);

            $mail->addAddress($to);
            $mail->Subject = $subject;
            $mail->msgHTML($html);
            $mail->AltBody = strip_tags($html);

            foreach ($attachments as $file) {
                $mail->addAttachment($file);
            }

            $mail->send();
        } catch (PHPMailerException $e) {
            \Log::error('[SMTP PluginMailer] Error al enviar: '.$e->getMessage());
            throw $e;
        }
    }
}